Frogger Remake by H.Spring
--------------------------

This is my remake of the old Sega arcade game - Frogger.

Instructions
------------
Guide Frogger across the road with out being run over.  Then make him jump from log to 
turtle to get to one of the five homes at the top of the screen (poor Frogger hasn't
learnt to swim yet!)

On the way, collect a lady frog and she will give you bonus points when you get home.  
Various tokens also float across the middle - collect these for extra lives (note: collecting letters of
FROG will give you an extra life if you complete the current level).You can also gain points by eating a
fly when getting home

Watch out, not only for maniac drivers but sinking turtles, frog eating snake and 
crocodiles!

I have hidden a number of secrets within the game that get you extra lives or big
points.  If you find a secret, it will quickly flash up on the screen so think carefully
about your every move to learn all the secrets and become top frog!

Controls
--------

Use the cursor keys to move the frog left/right and up/down.
M turns the music off and N turns it back on again.
Press escape when playing to exit the game and return to windows.

That's it, have fun.  If you have any bug reports or comments feel free to email me at:

havard@v21.me.uk

Credits
-------

Game programmed by H Spring
Graphics by Ric (cheeky Monkey)
Support and playtesting by Andrew Pointon (TCK)

Thanks to Sega for the original game.

Check out more great games at:

http://havard.v21hosting.co.uk/

and

http://www.remakes.org/website/index.php

Version
-------

Froggerfinal - hopefully the one and only version?

Frogger Remake (c) H. Spring 2004